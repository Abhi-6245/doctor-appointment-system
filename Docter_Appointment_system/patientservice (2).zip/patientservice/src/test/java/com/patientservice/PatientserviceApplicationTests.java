package com.patientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
